package Question1;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.assertEquals;


public class MovieTicketsTest {

    private MovieTickets movieTickets;
    private String[] movieNames;
    private String[] months;
    private int[][] ticketSales;

    @BeforeEach
    public void setUp() {
        // Set up test data for the MovieTickets instance
        movieNames = new String[]{"Napoleon", "Oppenheimer"};
        months = new String[]{"JAN", "FEB", "MAR"};
        ticketSales = new int[][]{
            {3000, 1500, 1700},
            {3500, 1200, 1600}
        };
        movieTickets = new MovieTickets(movieNames, months, ticketSales);
    }

    @Test
    public void CalculateTotalSales_ReturnsExpectedTotalSales() {
        // Test for Napoleon's ticket sales total
        int[] napoleonSales = ticketSales[0];
        int expectedTotal = 3000 + 1500 + 1700;
        int actualTotal = movieTickets.TotalMovieSales(napoleonSales);

        assertEquals(expectedTotal, actualTotal, "The total ticket sales for Napoleon should match the expected total.");
    }

    @Test
    public void TopMovieSales_ReturnsTopMovie() {
        // Calculate total sales for each movie
        int[] totalSales = new int[movieNames.length];
        for (int i = 0; i < ticketSales.length; i++) {
            totalSales[i] = movieTickets.TotalMovieSales(ticketSales[i]);
        }

        // Test for the top-performing movie
        String expectedTopMovie = "Napoleon";
        String actualTopMovie = movieTickets.TopMovie(movieNames, totalSales);

        assertEquals(expectedTopMovie, actualTopMovie, "The top-performing movie should be Napoleon.");
    }
}


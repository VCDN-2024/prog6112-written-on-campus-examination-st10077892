package Question1;

public class ST10077892PROGEXAMQ1 {

    public static void main(String[] args) {
        String[] MovieNames_Arr = {"Napoleon", "Oppenheimer"}; // Array storing movie names
        String[] Months_Arr = {"JAN", "FEB", "MAR"}; // Array storing months

        double[][] TicketSales_Arr = { // 2D array storing ticket sales for each movie per month
            {3000, 1500, 1700},
            {3500, 1200, 1600}
        };

        // Display header for sales report
        System.out.println("MOVIE TICKET SALES REPORT");
        System.out.print("Movie           ");
        for (String month : Months_Arr) {
            System.out.print(month + "          ");
        }
        System.out.println();
        System.out.println("--------------------------------------------------");

        // Display ticket sales for each movie
        for (int i = 0; i < MovieNames_Arr.length; i++) {
            System.out.print(MovieNames_Arr[i] + "       ");
            for (int j = 0; j < TicketSales_Arr[i].length; j++) {
                System.out.print(TicketSales_Arr[i][j] + "           ");
            }
            System.out.println();
        }

        System.out.println();

        // Calculate and display total ticket sales for each movie
        for (int i = 0; i < TicketSales_Arr.length; i++) {
            double totalSales = calculateTotalSales(TicketSales_Arr[i]);
            System.out.println("Total ticket sales for " + MovieNames_Arr[i] + ": " + totalSales);
        }

        System.out.println();

        // Identify and display the top-performing movie based on total ticket sales
        int topPerformingMovieIndex = getTopPerformingMovie(TicketSales_Arr);
        System.out.println("Top-performing movie: " + MovieNames_Arr[topPerformingMovieIndex]);
    }

    // Method to calculate total ticket sales for a given movie
    public static double calculateTotalSales(double[] sales) {
        double total = 0;
        for (double sale : sales) {
            total += sale;
        }
        return total;
    }

    // Method to find the movie with the highest total sales
    public static int getTopPerformingMovie(double[][] sales) {
        int topIndex = 0;
        double maxSales = calculateTotalSales(sales[0]);

        for (int i = 1; i < sales.length; i++) {
            double totalSales = calculateTotalSales(sales[i]);
            if (totalSales > maxSales) {
                maxSales = totalSales;
                topIndex = i;
            }
        }
        return topIndex;
    }
}

//Title: Loop Trough Array
//Author: W3Schools
//Date: 12 November 2024
//Version: 1
//Available:https://www.w3schools.com/java/java_arrays_loop.asp

//Title: Java Multidimensional Arrays
//Author: W3Schools
//Date: 12 November 2024
//Version: 1
//Available:https://www.w3schools.com/java/java_arrays_multi.asp

//Title: How to loop over two dimensional array in java
//Author: Java Revisited
//Date: 12 November 2024
//Version: 1
//Available:https://javarevisited.blogspot.com/2015/09/how-to-loop-two-dimensional-array-in-java.html#axzz8JoRe4Ool

//Title: PROG6112 Exam Brief Files
//Author: Tutor Keenan
//Date: 12 November 2024
//Version: 1
//Available: VC Learn

    



 
    


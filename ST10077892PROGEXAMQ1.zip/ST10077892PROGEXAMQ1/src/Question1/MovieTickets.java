package Question1;


public class MovieTickets implements IMovieTickets {
    private String[] movieNames;
    private String[] months;
    private int[][] ticketSales;

    public MovieTickets(String[] movieNames, String[] months, int[][] ticketSales) {
        this.movieNames = movieNames;
        this.months = months;
        this.ticketSales = ticketSales;
    }

    // Method to calculate total ticket sales for a specific movie
    @Override
    public int TotalMovieSales(int[] movieTicketSales) {
        int total = 0;
        for (int sales : movieTicketSales) {
            total += sales;
        }
        return total;
    }

    // Method to find the top-performing movie based on total sales
    @Override
    public String TopMovie(String[] movies, int[] totalSales) {
        int topIndex = 0;
        int maxSales = totalSales[0];

        for (int i = 1; i < totalSales.length; i++) {
            if (totalSales[i] > maxSales) {
                maxSales = totalSales[i];
                topIndex = i;
            }
        }
        return movies[topIndex];
    }

    // Method to display the ticket sales report
    public void displaySalesReport() {
        System.out.println("MOVIE TICKET SALES REPORT");
        System.out.print("Movie           ");
        for (String month : months) {
            System.out.print(month + "          ");
        }
        System.out.println();
        System.out.println("--------------------------------------------------");

        // Display ticket sales for each movie
        for (int i = 0; i < movieNames.length; i++) {
            System.out.print(movieNames[i] + "       ");
            for (int j = 0; j < ticketSales[i].length; j++) {
                System.out.print(ticketSales[i][j] + "           ");
            }
            System.out.println();
        }

        System.out.println();

        // Calculate and display total ticket sales for each movie
        int[] totalSales = new int[movieNames.length];
        for (int i = 0; i < ticketSales.length; i++) {
            totalSales[i] = TotalMovieSales(ticketSales[i]);
            System.out.println("Total ticket sales for " + movieNames[i] + ": " + totalSales[i]);
        }

        System.out.println();

        // Identify and display the top-performing movie based on total ticket sales
        String topMovie = TopMovie(movieNames, totalSales);
        System.out.println("Top-performing movie: " + topMovie);
    }
}

//Title: 2D Array Quarterly Sales Demo
//Author: Code Hammer Bootcamp
//Date: 12 November 2024
//Version: 1
//Available:https://www.youtube.com/watch?v=aaKBJ7OAieA 

//Title: PROG6112 Exam Brief Files
//Author: Tutor Keenan
//Date: 12 November 2024
//Version: 1
//Available: VC Learn



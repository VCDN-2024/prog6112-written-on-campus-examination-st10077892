package Question1;

public interface IMovieTickets {
    int TotalMovieSales(int[] movieTicketSales);
    String TopMovie(String[] movies, int[]totalSales);
}

//Title: PROG6112 Exam Brief Files
//Author: Tutor Keenan
//Date: 12 November 2024
//Version: 1
//Available: VC Learn

//Title: PROG6112 Exam Question Paper 2024
//Author: IIE Varsity College
//Date: 12 November 2024
//Version: 1
//Available: IIE Varsity College

package Question2;

import javax.swing.JOptionPane;

public class MovieTicket extends javax.swing.JFrame implements IMovieTicket {

    // Creating an instance of the MovieTickets class
    MovieTickets movieTickets = new MovieTickets();

    public MovieTicket() {
        initComponents();
    }

    // Implement the CalculateTotalTicketPrice method from the IMovieTicket interface
    @Override
    public double CalculateTotalTicketPrice(int numberOfTickets, double ticketPrice) {
        double totalPrice = numberOfTickets * ticketPrice;
        double vat = totalPrice * 0.14; // 14% VAT
        return totalPrice + vat; // Return total price including VAT
    }

    // Implement the ValidateData method from the IMovieTicket interface
    @Override
    public boolean ValidateData(MovieTicketData movieTicketData) {
        if (movieTicketData.getMovieName().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Movie name cannot be empty.");
            return false;
        }
        if (movieTicketData.getTicketPrice() <= 0) {
            JOptionPane.showMessageDialog(this, "Ticket price must be greater than 0.");
            return false;
        }
        if (movieTicketData.getNumberOfTickets() <= 0) {
            JOptionPane.showMessageDialog(this, "Number of tickets must be greater than 0.");
            return false;
        }
        return true; // Return true if all data is valid
    }

    // Process ticket sales: validate inputs, calculate total price, and display report
    private void processTicketSales() {
        String selectedMovie = movieComboBox.getSelectedItem().toString();
        String ticketPriceText = ticketPriceField.getText();
        String numTicketsText = numTicketsField.getText();

        // Create a MovieTicketData object with the entered values
        MovieTicketData movieTicketData = new MovieTicketData(
                selectedMovie, 
                Double.parseDouble(ticketPriceText), 
                Integer.parseInt(numTicketsText)
        );

        // Validate movie ticket data
        if (!ValidateData(movieTicketData)) {
            return; // Stop if validation fails
        }

        // Calculate total ticket price with VAT
        double totalSalesWithVat = CalculateTotalTicketPrice(
                movieTicketData.getNumberOfTickets(), 
                movieTicketData.getTicketPrice()
        );

        // Display the report in the text area
        reportArea.setText("Movie: " + selectedMovie + "\n" +
                           "Ticket Price: R" + movieTicketData.getTicketPrice() + "\n" +
                           "Number of Tickets: " + movieTicketData.getNumberOfTickets() + "\n" +
                           "Total Sales (excl. VAT): R" + (movieTicketData.getTicketPrice() * movieTicketData.getNumberOfTickets()) + "\n" +
                           "VAT (14%): R" + ((movieTicketData.getTicketPrice() * movieTicketData.getNumberOfTickets()) * 0.14) + "\n" +
                           "Total Sales (incl. VAT): R" + totalSalesWithVat);
    }

    // Clear fields method
    private void clearFields() {
        ticketPriceField.setText("");
        numTicketsField.setText("");
        reportArea.setText("");
    }

    // Exit application method
    private void exitApplication() {
        System.exit(0);
    }

    // Generated GUI components and event handling methods below...

    // Action listener for Process menu item
    private void jMenuItemProcessActionPerformed(java.awt.event.ActionEvent evt) {                                                
        processTicketSales();
    }

    // Action listener for Clear menu item
    private void jMenuItemClearActionPerformed(java.awt.event.ActionEvent evt) {                                               
        clearFields();
    }

    // Action listener for Exit menu item
    private void jMenuItemExitActionPerformed(java.awt.event.ActionEvent evt) {                                               
        exitApplication();
    }

    // Main method
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MovieTicket().setVisible(true);
            }
        });
    }

    private void initComponents() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

//Title: PROG6112 Exam Brief Files
//Author: Tutor Keenan
//Date: 12 November 2024
//Version: 1
//Available: VC Learn
package Question2;

public interface IMovieTicket {
    double CalculateTotalTicketPrice(int numberOfTickets, double ticketPrice);
    boolean ValidateData(MovieTicketData movieTicketData);
}

//Title: PROG6112 Exam Brief Files
//Author: Tutor Keenan
//Date: 12 November 2024
//Version: 1
//Available: VC Learn

//Title: PROG6112 Exam Question Paper 2024
//Author: IIE Varsity College
//Date: 12 November 2024
//Version: 1
//Available: IIE Varsity College
